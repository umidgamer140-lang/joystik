package uz.elevate.padmap

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class MType { TAP, SWIPE, STICK, DPAD }

/**
 * Bitta bog'lanish. Koordinatalar ekranga nisbatan ulush (0..1).
 * TAP   – tugma bosilib turganda (x,y) nuqta bosilib turadi
 * SWIPE – (x,y) dan bosib (x2,y2) ga suriladi, tugma qo'yib yuborilguncha ushlab turiladi
 * STICK – analog stik (ax, ay o'qlari) -> markazi (x,y), radiusi r bo'lgan ekran joystigi
 * DPAD  – 4 tugma (up/down/left/right) -> xuddi shu ekran joystigi
 * mod   – kombinatsiya: shu tugma bosib turilgandagina ishlaydi (0 = yo'q)
 */
class Mapping(var type: MType) {
    var key = 0
    var mod = 0
    var x = 0.5f
    var y = 0.5f
    var x2 = 0.5f
    var y2 = 0.7f
    var r = 0.15f
    var ax = 0
    var ay = 1
    var up = Codes.HAT_UP
    var down = Codes.HAT_DOWN
    var left = Codes.HAT_LEFT
    var right = Codes.HAT_RIGHT
    var ms = 180
    /** Ekranda ko'rinadigan nom (Pass, Shoot ...) */
    var name = ""
    /** SWIPE uchun: bir xil group = bitta shoot doirasi, har biri alohida yo'nalish */
    var group = 0

    fun toJson(): JSONObject = JSONObject()
        .put("t", type.name).put("key", key).put("mod", mod)
        .put("x", x.toDouble()).put("y", y.toDouble())
        .put("x2", x2.toDouble()).put("y2", y2.toDouble())
        .put("r", r.toDouble()).put("ax", ax).put("ay", ay)
        .put("up", up).put("down", down).put("left", left).put("right", right)
        .put("ms", ms).put("name", name).put("group", group)

    companion object {
        fun fromJson(o: JSONObject): Mapping = Mapping(MType.valueOf(o.optString("t", "TAP"))).apply {
            key = o.optInt("key")
            mod = o.optInt("mod")
            x = o.optDouble("x", 0.5).toFloat()
            y = o.optDouble("y", 0.5).toFloat()
            x2 = o.optDouble("x2", 0.5).toFloat()
            y2 = o.optDouble("y2", 0.7).toFloat()
            r = o.optDouble("r", 0.15).toFloat()
            ax = o.optInt("ax", 0)
            ay = o.optInt("ay", 1)
            up = o.optInt("up", Codes.HAT_UP)
            down = o.optInt("down", Codes.HAT_DOWN)
            left = o.optInt("left", Codes.HAT_LEFT)
            right = o.optInt("right", Codes.HAT_RIGHT)
            ms = o.optInt("ms", 180)
            name = o.optString("name", "")
            group = o.optInt("group", 0)
        }
    }
}

object Profile {
    fun toJson(list: List<Mapping>): String =
        JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()

    fun fromJson(s: String?): MutableList<Mapping> {
        val out = mutableListOf<Mapping>()
        if (s.isNullOrEmpty()) return out
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) out.add(Mapping.fromJson(a.getJSONObject(i)))
        } catch (_: Exception) {
        }
        // Eski profillar: guruhsiz SWIPE'larga alohida guruh beramiz
        var next = (out.maxOfOrNull { it.group } ?: 0) + 1
        out.filter { it.type == MType.SWIPE && it.group == 0 }.forEach { it.group = next++ }
        return out
    }

    private fun prefs(c: Context) = c.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    fun load(c: Context, pkg: String) = fromJson(prefs(c).getString(pkg, null))
    fun save(c: Context, pkg: String, list: List<Mapping>) =
        prefs(c).edit().putString(pkg, toJson(list)).apply()
}

/** Linux input kodlari + bizning virtual kodlar. */
object Codes {
    const val HAT_UP = 1001
    const val HAT_DOWN = 1002
    const val HAT_LEFT = 1003
    const val HAT_RIGHT = 1004
    /** Analog o'q (masalan trigger) tugma sifatida: ABS_BTN + absCode */
    const val ABS_BTN = 2000

    fun name(c: Int): String = when (c) {
        0 -> "—"
        304 -> "A"
        305 -> "B"
        306 -> "C"
        307 -> "X"
        308 -> "Y"
        309 -> "Z"
        310 -> "LB"
        311 -> "RB"
        312 -> "L2"
        313 -> "R2"
        314 -> "SELECT"
        315 -> "START"
        316 -> "HOME"
        317 -> "L3"
        318 -> "R3"
        544, HAT_UP -> "↑"
        545, HAT_DOWN -> "↓"
        546, HAT_LEFT -> "←"
        547, HAT_RIGHT -> "→"
                        ABS_BTN + 9 -> "R2"
        ABS_BTN + 10 -> "L2"
        else -> when {
            c in STICK_DIR until STICK_DIR + 128 -> dirName(c)
            c >= ABS_BTN && c < 3000 -> "AXIS${c - ABS_BTN}"
            else -> "K$c"
        }
    }

    /** Stik yo'nalishi tugma sifatida: STICK_DIR + o'q*2 + (musbat ? 1 : 0) */
    const val STICK_DIR = 4000

    fun dir(axis: Int, positive: Boolean) = STICK_DIR + axis * 2 + (if (positive) 1 else 0)

    private fun dirName(c: Int): String {
        val axis = (c - STICK_DIR) / 2
        val pos = (c - STICK_DIR) % 2 == 1
        val stick = if (axis == 0 || axis == 1) "LS" else "RS"   // chap / o'ng stik
        val vertical = axis == 1 || axis == 4 || axis == 5
        val arrow = if (vertical) (if (pos) "↓" else "↑") else (if (pos) "→" else "←")
        return stick + arrow
    }

    fun label(m: Mapping): String = (if (m.mod != 0) name(m.mod) + "+" else "") + name(m.key)

    /** Android KeyEvent kodini Linux kodiga (tahrirlashda Shizuku'siz tugma tanlash uchun) */
    fun fromKeyCode(k: Int): Int = when (k) {
        96 -> 304; 97 -> 305; 98 -> 306; 99 -> 307; 100 -> 308; 101 -> 309
        102 -> 310; 103 -> 311; 104 -> 312; 105 -> 313; 106 -> 317; 107 -> 318
        108 -> 315; 109 -> 314; 110 -> 316
        19 -> HAT_UP; 20 -> HAT_DOWN; 21 -> HAT_LEFT; 22 -> HAT_RIGHT
        else -> -1
    }

    fun stickName(ax: Int, ay: Int): String = when (ax) {
        0 -> "Joystik (X/Y)"
        2 -> "Joystik (Z/RZ)"
        3 -> "Joystik (RX/RY)"
        else -> "Joystik $ax/$ay"
    }
}

/** Tayyor shablonlar. Koordinatalar taxminiy — o'yinda sudrab moslanadi. */
object Presets {
    private fun tap(n: String, k: Int, x: Float, y: Float, r: Float) =
        Mapping(MType.TAP).apply { name = n; key = k; this.x = x; this.y = y; this.r = r }

    private fun swipe(k: Int, m: Int, x2: Float, y2: Float) = Mapping(MType.SWIPE).apply {
        name = "Shoot"; group = 1; key = k; mod = m
        x = 0.90f; y = 0.70f; r = 0.08f; this.x2 = x2; this.y2 = y2; ms = 180
    }

    /** FC Mobile (gorizontal ekran, standart joylashuv) */
    fun fcMobile(): MutableList<Mapping> = mutableListOf(
        Mapping(MType.STICK).apply { name = "Harakat"; x = 0.13f; y = 0.72f; r = 0.17f; ax = 0; ay = 1 },
        tap("Pass", 304, 0.76f, 0.84f, 0.065f),     // A
        tap("Shoot", 305, 0.90f, 0.70f, 0.08f).apply { group = 1 },  // B — Shoot doirasining o'zi
        tap("Through", 307, 0.79f, 0.63f, 0.06f),   // X
        tap("Skill", 308, 0.69f, 0.66f, 0.055f),    // Y
        tap("Sprint", 311, 0.65f, 0.86f, 0.06f),    // RB
        swipe(305, 310, 0.90f, 0.90f),              // LB + B  -> shoot pastga
        swipe(308, 310, 0.90f, 0.50f),              // LB + Y  -> shoot tepaga
    )
}
