package uz.elevate.padmap

import android.annotation.SuppressLint
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * O'yin ustidagi tahrirlash oynasi.
 * - Har bir qo'shishda AVVAL gamepad tugmasi so'raladi, keyin boshqaruv chiqadi.
 * - Shoot doirasi: o'zining tugmasi (oddiy bosish) + "＋" bilan qo'shiladigan surish tomonlari (kombo bilan).
 * - Tugma tanlash ikki yo'l bilan: Shizuku orqali yoki shu oynaning o'zi (Shizuku'siz ham ishlaydi).
 */
@SuppressLint("ViewConstructor")
class EditorView(private val svc: OverlayService) : FrameLayout(svc) {

    private enum class Part { BODY, END, PLUS }

    private val d = resources.displayMetrics.density
    private val maps get() = svc.maps

    private var sel: Mapping? = null
    private var selPart = Part.BODY

    private var dragM: Mapping? = null
    private var dragPart = Part.BODY
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false

    // tugma kutish holati
    private var capMode = 0
    private var capCb: ((Int) -> Unit)? = null

    private val cTap = 0xFF2979FF.toInt()
    private val cSwipe = 0xFFFF6D00.toInt()
    private val cStick = 0xFF00C853.toInt()
    private val cDpad = 0xFFAA00FF.toInt()
    private val cPlus = 0xFF00E676.toInt()
    private val cSel = 0xFFFFD600.toInt()
    private val cBar = 0xE6161A22.toInt()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3 * d; strokeCap = Paint.Cap.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true
        setShadowLayer(3 * d, 0f, 0f, Color.BLACK)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 10 * d; textAlign = Paint.Align.CENTER
        setShadowLayer(3 * d, 0f, 0f, Color.BLACK)
    }

    private val info: TextView
    private val status: LinearLayout
    private val statusText: TextView
    private val statusBtns: LinearLayout
    private val panel: LinearLayout
    private val hudBtn: TextView

    init {
        setWillNotDraw(false)
        isFocusable = true
        isFocusableInTouchMode = true
        // O'yin ko'rinib tursin — juda och fon
        setBackgroundColor(0x33000000)

        val top = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = round(cBar, 14f)
        }
        top.addView(btn("+ Tugma", cTap) { addTap() })
        top.addView(btn("+ Shoot-surish", cSwipe) { addShoot() })
        top.addView(btn("+ Joystik", cStick) { addStick() })
        top.addView(btn("+ D-pad", cDpad) { addDpad() })
        top.addView(btn("⚽ FC Mobile shabloni") { applyPreset() })
        hudBtn = btn(hudLabel()) { svc.toggleHud(); hudBtnRefresh() }
        top.addView(hudBtn)
        top.addView(btn("✓ Saqlash", 0xFF2E7D32.toInt()) { svc.closeEditor(true) })
        top.addView(btn("Bekor") { svc.closeEditor(false) })
        top.addView(btn("↻ Yangilash") { svc.reconnect() })
        top.addView(btn("✕ Chiqish", 0xFFC62828.toInt()) { svc.closeEditor(false); svc.stopSelf() })

        info = TextView(context).apply {
            setTextColor(Color.WHITE); textSize = 12f
            setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
            background = round(0xCC000000.toInt(), 8f)
        }

        top.background = null
        top.gravity = Gravity.CENTER
        addView(HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            addView(top, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP)
            .apply { topMargin = (4 * d).toInt() })
        addView(info, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            .apply { topMargin = (52 * d).toInt() })

        statusText = TextView(context).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }
        statusBtns = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, (10 * d).toInt(), 0, 0)
        }
        status = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding((22 * d).toInt(), (16 * d).toInt(), (22 * d).toInt(), (16 * d).toInt())
            background = round(0xF2101318.toInt(), 18f).apply { setStroke((1 * d).toInt(), 0x55FFFFFF) }
            visibility = View.GONE
            addView(statusText); addView(statusBtns)
        }
        addView(status, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        panel = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
        }
        addView(HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            addView(panel, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            .apply { bottomMargin = (6 * d).toInt() })
        updateInfo()
        select(null)
    }

    fun updateInfo() {
        info.text = "${svc.accState}   •   ${svc.padState}"
    }

    private fun hudLabel() = if (svc.hudOn) "👁 O'yinda ko'rinsin: Ha" else "👁 O'yinda ko'rinsin: Yo'q"
    private fun hudBtnRefresh() { hudBtn.text = hudLabel() }

    private fun round(color: Int, rad: Float = 10f) = GradientDrawable().apply { cornerRadius = rad * d; setColor(color) }

    private fun btn(label: String, color: Int = 0xFF2A303B.toInt(), onClick: () -> Unit) =
        TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            background = round(color)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0) }
        }

    // ================= tugma kutish =================

    private fun ask(msg: String, mode: Int, skip: String? = null, onSkip: (() -> Unit)? = null, onCode: (Int) -> Unit) {
        statusText.text = msg
        statusBtns.removeAllViews()
        if (skip != null) statusBtns.addView(btn(skip, 0xFF37474F.toInt()) { stopCapture(); onSkip?.invoke() })
        statusBtns.addView(btn("Bekor qilish", 0xFF5D2A2A.toInt()) { stopCapture() })
        status.visibility = View.VISIBLE
        capMode = mode
        capCb = onCode
        requestFocus()
        svc.capture(mode) { code -> if (code >= 0) deliver(code) }
    }

    private var lastCode = -1
    private var lastTime = 0L

    private fun deliver(code: Int) {
        // Bir bosish ikki yo'l bilan (Shizuku + oyna) kelsa, ikkinchisini e'tiborsiz qoldiramiz
        val now = android.os.SystemClock.uptimeMillis()
        if (code == lastCode && now - lastTime < 400) return
        lastCode = code; lastTime = now
        val cb = capCb ?: return
        stopCapture()
        cb(code)
        select(sel, selPart)
    }

    private fun stopCapture() {
        capMode = 0
        capCb = null
        svc.cancelCapture()
        status.visibility = View.GONE
        select(sel, selPart)
    }

    /** Shizuku'siz: gamepad tugmalari to'g'ridan-to'g'ri shu oynaga keladi */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val isPad = KeyEvent.isGamepadButton(e.keyCode) ||
            (e.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (e.source and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
        if (isPad) {
            if (capMode == 1 && e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                val c = Codes.fromKeyCode(e.keyCode)
                if (c >= 0) deliver(c)
            }
            return true // o'yinga/tizimga o'tkazmaymiz (B → "orqaga" bo'lib qolmasin)
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) {
            return super.dispatchGenericMotionEvent(e)
        }
        if (capMode == 2) {
            val pairs = listOf(
                Triple(MotionEvent.AXIS_X, MotionEvent.AXIS_Y, 0 or (1 shl 16)),
                Triple(MotionEvent.AXIS_RX, MotionEvent.AXIS_RY, 3 or (4 shl 16)),
                Triple(MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ, 2 or (5 shl 16)),
            )
            for ((a, b, code) in pairs) {
                if (abs(e.getAxisValue(a)) > 0.6f || abs(e.getAxisValue(b)) > 0.6f) { deliver(code); break }
            }
        } else if (capMode == 1) {
            val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            when {
                hy < -0.5f -> deliver(Codes.HAT_UP)
                hy > 0.5f -> deliver(Codes.HAT_DOWN)
                hx < -0.5f -> deliver(Codes.HAT_LEFT)
                hx > 0.5f -> deliver(Codes.HAT_RIGHT)
                e.getAxisValue(MotionEvent.AXIS_BRAKE) > 0.5f -> deliver(Codes.ABS_BTN + 10)
                e.getAxisValue(MotionEvent.AXIS_GAS) > 0.5f -> deliver(Codes.ABS_BTN + 9)
            }
        }
        return true
    }

    /** Avval asosiy tugma, keyin (ixtiyoriy) kombo tugma */
    private fun askKeyThenMod(title: String, done: (Int, Int) -> Unit) {
        ask("$title\n\nGamepad'da tugmani bosing…", 1) { key ->
            ask("${Codes.name(key)} tanlandi.\n\nKombo: birga BOSIB TURILADIGAN tugmani bosing\n(tugma bosing yoki o'ng stikni kerakli tomonga suring — masalan RS↓)",
                1, "Kombosiz", { done(key, 0) }) { mod ->
                done(key, if (mod == key) 0 else mod)
            }
        }
    }

    // ================= guruh (Shoot doirasi) =================

    private fun nextGroup() = (maps.maxOfOrNull { it.group } ?: 0) + 1
    private fun groupItems(g: Int) = maps.filter { it.group == g && g != 0 }
    private fun dirsOf(g: Int) = maps.filter { it.type == MType.SWIPE && it.group == g }
    private fun bodyOf(g: Int) = maps.firstOrNull { it.type == MType.TAP && it.group == g }
    private fun groups() = maps.filter { it.group != 0 }.groupBy { it.group }.values.toList()

    // ================= qo'shish =================

    private fun addTap() = askKeyThenMod("Yangi tugma") { k, md ->
        val m = Mapping(MType.TAP).apply { key = k; mod = md; r = 0.06f; x = 0.5f; y = 0.5f }
        maps.add(m); select(m, Part.BODY)
    }

    /** 1) Shoot'ning o'z tugmasi  2) surish tugmasi  3) kombo */
    private fun addShoot() {
        ask("Shoot doirasi\n\n1) SHOOT tugmasini bosing (masalan X)", 1, "Tugmasiz", { addShootDir(0) }) { k ->
            addShootDir(k)
        }
    }

    private fun addShootDir(bodyKey: Int) {
        askKeyThenMod("2) SURISH uchun tugma (masalan Y)") { k, md ->
            val g = nextGroup()
            if (bodyKey != 0) maps.add(Mapping(MType.TAP).apply {
                group = g; name = "Shoot"; key = bodyKey; x = 0.85f; y = 0.62f; r = 0.075f
            })
            val m = Mapping(MType.SWIPE).apply {
                group = g; name = "Shoot"; key = k; mod = md
                x = 0.85f; y = 0.62f; r = 0.075f; x2 = 0.85f; y2 = 0.82f
            }
            maps.add(m); select(m, Part.END)
            svc.toast("Katta doirani Shoot ustiga qo'ying, kichigini surish tomonga. ＋ — yana tomon qo'shish")
        }
    }

    private val dirs = listOf(0 to 1, 0 to -1, -1 to 0, 1 to 0, -1 to 1, 1 to 1, -1 to -1, 1 to -1)

    private fun addDirection(g: Int) {
        val f = groupItems(g).firstOrNull() ?: return
        askKeyThenMod("Yangi surish tomoni") { k, md ->
            val n = dirsOf(g).size
            val (dx, dy) = dirs[n % dirs.size]
            val m = Mapping(MType.SWIPE).apply {
                group = g; name = f.name; key = k; mod = md; ms = dirsOf(g).firstOrNull()?.ms ?: 180
                x = f.x; y = f.y; r = f.r
                x2 = (f.x + dx * 0.09f).coerceIn(0f, 1f)
                y2 = (f.y + dy * 0.18f).coerceIn(0f, 1f)
            }
            maps.add(m); select(m, Part.END)
        }
    }

    private fun setBodyKey(g: Int) {
        val f = groupItems(g).firstOrNull() ?: return
        askKeyThenMod("Shoot doirasining tugmasi") { k, md ->
            val b = bodyOf(g) ?: Mapping(MType.TAP).apply {
                group = g; name = f.name; x = f.x; y = f.y; r = f.r
            }.also { maps.add(it) }
            b.key = k; b.mod = md
            select(f, Part.BODY)
        }
    }

    private fun addStick() = ask("Joystik\n\nStikni bir tomonga oxirigacha suring…", 2) { c ->
        val m = Mapping(MType.STICK).apply {
            ax = c and 0xffff; ay = (c shr 16) and 0xffff; x = 0.15f; y = 0.70f; r = 0.16f
        }
        maps.add(m); select(m, Part.BODY)
    }

    private fun addDpad() {
        val m = Mapping(MType.DPAD).apply { x = 0.15f; y = 0.70f; r = 0.16f }
        maps.add(m); select(m, Part.BODY)
    }

    private fun applyPreset() {
        maps.clear()
        maps.addAll(Presets.fcMobile())
        select(null)
        // Har gamepadda chap stik o'qi har xil bo'lishi mumkin — shuning uchun so'raymiz
        val stick = maps.firstOrNull { it.type == MType.STICK }
        if (stick != null) {
            ask("FC Mobile shabloni\n\nHarakat uchun CHAP stikni bir tomonga oxirigacha suring…", 2, "O'tkazib yuborish", {
                svc.toast("Tugmalarni o'yindagi joyiga sudrab moslang, keyin Saqlash")
            }) { c ->
                stick.ax = c and 0xffff; stick.ay = (c shr 16) and 0xffff
                svc.toast("Tayyor. Tugmalarni o'yindagi joyiga sudrab moslang, keyin Saqlash")
            }
        }
    }

    // ================= panel =================

    private fun select(m: Mapping?, part: Part = Part.BODY) {
        sel = m; selPart = part
        panel.removeAllViews()
        if (m == null) {
            panel.addView(btn("Bosib tanlang • sudrab joylang • yashil ＋ — yangi surish tomoni") {})
            invalidate(); return
        }
        when {
            m.group != 0 && part == Part.BODY -> {
                val g = m.group
                val b = bodyOf(g)
                panel.addView(btn("Shoot tugmasi: ${b?.let { Codes.label(it) } ?: "yo'q"}") { setBodyKey(g) })
                if (b != null) panel.addView(btn("Tugmani olib tashlash") { maps.remove(b); select(groupItems(g).firstOrNull(), Part.BODY) })
                panel.addView(btn("＋ Surish tomoni", 0xFF00A152.toInt()) { addDirection(g) })
                sizeButtons(groupItems(g), 0.01f, 0.03f, 0.15f)
                panel.addView(btn("🗑 Doirani o'chirish", 0xFFC62828.toInt()) {
                    maps.removeAll { it.group == g }; select(null)
                })
            }
            m.type == MType.TAP -> {
                keyButtons(m)
                sizeButtons(listOf(m), 0.01f, 0.03f, 0.15f)
                panel.addView(btn("🗑 O'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
            m.type == MType.SWIPE -> {
                keyButtons(m)
                panel.addView(btn("Surish: ${m.ms} ms") {
                    m.ms = when (m.ms) { 80 -> 120; 120 -> 180; 180 -> 250; 250 -> 350; else -> 80 }
                    select(m, part)
                })
                panel.addView(btn("🗑 Bu tomonni o'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
            m.type == MType.STICK -> {
                panel.addView(btn("Stik: ${Codes.stickName(m.ax, m.ay)}") {
                    ask("Stikni bir tomonga oxirigacha suring…", 2) { c ->
                        m.ax = c and 0xffff; m.ay = (c shr 16) and 0xffff
                    }
                })
                sizeButtons(listOf(m), 0.02f, 0.05f, 0.4f)
                panel.addView(btn("🗑 O'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
            else -> {
                panel.addView(btn("Yo'nalish tugmalari") { captureDpad(m) })
                sizeButtons(listOf(m), 0.02f, 0.05f, 0.4f)
                panel.addView(btn("🗑 O'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
        }
        invalidate()
    }

    private fun keyButtons(m: Mapping) {
        panel.addView(btn("Tugma: ${Codes.name(m.key)}") { ask("Gamepad'da yangi tugmani bosing…", 1) { m.key = it } })
        panel.addView(btn(if (m.mod == 0) "Kombo: yo'q" else "Kombo: ${Codes.name(m.mod)} bosib turilsa") {
            ask("Kombo: tugmani bosing yoki stikni kerakli tomonga suring…", 1) { if (it != m.key) m.mod = it }
        })
        if (m.mod != 0) panel.addView(btn("Kombo o'chirish") { m.mod = 0; select(m, selPart) })
    }

    private fun sizeButtons(list: List<Mapping>, step: Float, lo: Float, hi: Float) {
        panel.addView(btn("➕ Kattalashtirish") { list.forEach { it.r = (it.r + step).coerceAtMost(hi) }; invalidate() })
        panel.addView(btn("➖ Kichraytirish") { list.forEach { it.r = (it.r - step).coerceAtLeast(lo) }; invalidate() })
    }

    private fun captureDpad(m: Mapping) {
        ask("↑ YUQORI tugmani bosing…", 1) { u ->
            m.up = u
            ask("↓ PAST tugmani bosing…", 1) { dn ->
                m.down = dn
                ask("← CHAP tugmani bosing…", 1) { l ->
                    m.left = l
                    ask("→ O'NG tugmani bosing…", 1) { r -> m.right = r }
                }
            }
        }
    }

    // ================= chizish (shaffof) =================

    private fun minDim() = min(width, height).toFloat()
    private fun rad(m: Mapping) = m.r * minDim()

    private fun plusPos(f: Mapping): Pair<Float, Float> {
        val r = rad(f) * 0.78f
        return f.x * width + r to f.y * height - r
    }

    private fun disc(c: Canvas, x: Float, y: Float, r: Float, color: Int, selected: Boolean) {
        fill.color = (color and 0x00FFFFFF) or 0x44000000
        c.drawCircle(x, y, r, fill)
        ring.color = if (selected) cSel else (color and 0x00FFFFFF) or 0xDD000000.toInt()
        ring.strokeWidth = (if (selected) 3 else 2) * d
        c.drawCircle(x, y, r, ring)
    }

    private fun center(c: Canvas, s: String, x: Float, y: Float) = c.drawText(s, x, y + txt.textSize / 3, txt)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        for (m in maps) {
            if (m.group != 0) continue
            val cx = m.x * w; val cy = m.y * h; val r = rad(m); val s = m === sel
            when (m.type) {
                MType.TAP -> {
                    disc(c, cx, cy, r, cTap, s)
                    center(c, Codes.label(m), cx, cy)
                    if (m.name.isNotEmpty()) c.drawText(m.name, cx, cy + r + 13 * d, small)
                }
                MType.STICK -> {
                    disc(c, cx, cy, r, cStick, s)
                    disc(c, cx, cy, r * 0.35f, cStick, false)
                    c.drawText(m.name.ifEmpty { Codes.stickName(m.ax, m.ay) }, cx, cy + r + 13 * d, small)
                }
                MType.DPAD -> {
                    disc(c, cx, cy, r, cDpad, s)
                    center(c, "✚", cx, cy)
                    c.drawText(m.name.ifEmpty { "D-pad" }, cx, cy + r + 13 * d, small)
                }
                else -> {}
            }
        }
        for (g in groups()) {
            val f = g[0]
            val sx = f.x * w; val sy = f.y * h; val r = rad(f)
            for (m in g) {
                if (m.type != MType.SWIPE) continue
                val ex = m.x2 * w; val ey = m.y2 * h
                val es = m === sel && selPart == Part.END
                line.color = if (es) cSel else (cSwipe and 0x00FFFFFF) or 0xCC000000.toInt()
                c.drawLine(sx, sy, ex, ey, line)
                disc(c, ex, ey, 13 * d, cSwipe, es)
                c.drawText(Codes.label(m), ex, ey + 26 * d, small)
            }
            val gs = sel?.let { it.group == f.group && selPart == Part.BODY } == true
            disc(c, sx, sy, r, cSwipe, gs)
            val body = bodyOf(f.group)
            center(c, body?.let { Codes.label(it) } ?: "—", sx, sy)
            c.drawText(f.name.ifEmpty { "Shoot" }, sx, sy + r + 13 * d, small)
            val (px, py) = plusPos(f)
            fill.color = cPlus
            c.drawCircle(px, py, 12 * d, fill)
            center(c, "+", px, py)
        }
    }

    // ================= sudrash =================

    private fun hit(x: Float, y: Float): Pair<Mapping, Part>? {
        val w = width.toFloat(); val h = height.toFloat()
        for (g in groups()) {
            val (px, py) = plusPos(g[0])
            if (hypot(x - px, y - py) < 18 * d) return g[0] to Part.PLUS
        }
        for (m in maps.reversed()) {
            if (m.type == MType.SWIPE && hypot(x - m.x2 * w, y - m.y2 * h) < 22 * d) return m to Part.END
        }
        for (m in maps.reversed()) {
            val r = if (m.type == MType.TAP || m.type == MType.SWIPE) max(rad(m), 24 * d) else rad(m)
            if (hypot(x - m.x * w, y - m.y * h) < r) {
                val t = if (m.group != 0) groupItems(m.group).first() else m
                return t to Part.BODY
            }
        }
        return null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (status.visibility == View.VISIBLE) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val h = hit(e.x, e.y)
                if (h == null) { select(null); return true }
                dragM = h.first; dragPart = h.second
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val m = dragM ?: return true
                if (abs(e.x - downX) > 8 * d || abs(e.y - downY) > 8 * d) moved = true
                if (moved && dragPart != Part.PLUS) {
                    val dx = (e.x - lastX) / width
                    val dy = (e.y - lastY) / height
                    lastX = e.x; lastY = e.y
                    when {
                        dragPart == Part.END -> {
                            m.x2 = (m.x2 + dx).coerceIn(0f, 1f); m.y2 = (m.y2 + dy).coerceIn(0f, 1f)
                        }
                        m.group != 0 -> groupItems(m.group).forEach {
                            it.x += dx; it.y += dy
                            if (it.type == MType.SWIPE) { it.x2 += dx; it.y2 += dy }
                        }
                        else -> { m.x = (m.x + dx).coerceIn(0f, 1f); m.y = (m.y + dy).coerceIn(0f, 1f) }
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val m = dragM
                if (m != null) {
                    if (dragPart == Part.PLUS && !moved) addDirection(m.group)
                    else select(m, if (dragPart == Part.PLUS) Part.BODY else dragPart)
                }
                dragM = null
            }
            MotionEvent.ACTION_CANCEL -> dragM = null
        }
        return true
    }
}
